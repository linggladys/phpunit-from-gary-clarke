<?php

use App\Cart;
use PHPUnit\Framework\TestCase;


class CartTest extends TestCase
{
    protected $cart;

    protected function setUp(): void
    {
        $this->cart = new Cart();
//        create new cart before each test (so to avoid any duplication
    }

    protected function tearDown(): void
    {
        Cart::$tax=1.2;
    }

    /** @test */
    public function theCartValueCanChangeStatically()
    {
        Cart::$tax = 1.5;
//        hangover
        $this->cart->price = 10;
        $netPrice = $this->cart->getNetPrice();

        $this->assertEquals(15, $netPrice);
    }

    public function testCorrectNetPriceIsReturned()
    {

        $this->cart->price = 10;
        $netPrice = $this->cart->getNetPrice();

        $this->assertEquals(12, $netPrice);
    }

    /** @test */
    public function ATypeErrorWhenAddANonIntToThePrice()
    {
//    PHPUnit has methods build-in to throw expected errors
        try{
            $this->cart->addToPrice('fifteen');

            $this->fail('A TypeError should have been thrown');
//            if a code fails
        }catch (TypeError $error){
//            $this->cart->addToPrice('fifteen');
//            dd($error);
            $this->assertStringStartsWith('App\Cart::addToPrice():', $error->getMessage());
//            the assertions in the error
        }

    }


}