<?php

class ExampleAssertionsTest extends \PHPUnit\Framework\TestCase

/*@test*/
{
    public function testThatStringsMatch(){
        $string1 = 'testing';
        $string2 ='testing';

        $string3 = 'Testing';

        $this->assertSame($string1,$string2);
//        compare if they are the same or not

    }

    public function testThatNumbersAddUp(){
        $this -> assertEquals (10,6+4);
    }
}