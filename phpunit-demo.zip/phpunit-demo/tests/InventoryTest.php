<?php

class InventoryTest extends \PHPUnit\Framework\TestCase
{
//    connect to a database
    /** @group db */
    public function testProductsCanBeSet(){
//        Setup (create a new inventory class)

        $mockRepo = $this->createMock(\App\ProductRepository::class);

        $inventory = new \App\Inventory($mockRepo);

        $mockProductsArray = [
            ['id' => 1, 'name' => 'Lotuss Full Cream Milk'],
            ['id' => 2, 'name' => 'Lotuss Value Biscuit'],
        ];

        $mockRepo->expects($this->once())->method('fetchProducts')->willReturn($mockProductsArray);
//  // proof that the methods have been called
//        Do something
        $inventory->setProducts();
//        Make assertions
        $this->assertEquals('Lotuss Full Cream Milk', $inventory->getProducts()[0]['name']);
        $this->assertEquals('Lotuss Value Biscuit', $inventory->getProducts()[1]['name']);
    }
}