<?php

class MockProductsTest extends \PHPUnit\Framework\TestCase
{
    public function testMockProductsAreReturned(){
        $mockRepo = $this->createMock(\App\ProductRepository::class);

        $mockProductsArray = [
            ['id' => 1, 'name' => 'Lotuss Full Cream Milk'],
            ['id' => 2, 'name' => 'Lotuss Value Biscuit'],
        ];

        $mockRepo->method('fetchProducts')->willReturn($mockProductsArray);


        $products = $mockRepo->fetchProducts();

        $this->assertEquals('Lotuss Value Biscuit', $products[1]['name']);
    }
}