<?php

namespace App;

class Inventory
{
    private array $products;


    public function __construct(private ProductRepository $productsRepo)
    {

    }

    public function setProducts(){
        //...products
        $this->products = $this->productsRepo->fetchProducts();
    }

    /**
     * @param array $products
     */
    public function getProducts(): array
    {
       return $this->products;
    }
}