<?php

namespace App;

class Cart
{
    public float $price;
    public static float $tax = 1.2;

    public function getNetPrice(): float{
        return $this->price * self::$tax;
    }

//    create a system that captures if we go wrong
    public function addToPrice(int $amount)
    {
        $this->price += $amount;
    }
}